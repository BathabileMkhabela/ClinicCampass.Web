export default function SubTitle({subtitle}){
    return(
        <div className="subtitlePage_container">
            <p>{subtitle}</p>
        </div>
    );
}