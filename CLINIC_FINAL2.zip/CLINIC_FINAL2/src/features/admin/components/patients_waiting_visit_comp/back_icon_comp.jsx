import backBtnIcon from '../../../../assets/admin_assets/icons/back_arrow_white_button.svg'
export default function BackIconComp(){
    return(
        <div className='btn_icon_container'> 
             < img src={backBtnIcon} alt="" />
        </div>
           
     
    );
}