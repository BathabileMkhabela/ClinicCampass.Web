export default function UrgencyLeveltbComp({urgencyLevelClassColor="urgencyLevelClassColorCritical"}){
    return(
        <div className={urgencyLevelClassColor}>
        </div>
    );
}