import "../../../../../styles/modal.css"
export default function ModalActionComponent({actionBtsContainer}){
    return(
        <div className="modal_action_comp_container">
            {actionBtsContainer}
        </div>
    );
}