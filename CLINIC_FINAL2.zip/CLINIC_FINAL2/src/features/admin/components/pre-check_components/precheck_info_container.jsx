export default function PrecheckInfoContainer(){
    return (
        <div className="precheck_info_container">
            
        </div>
    );
}