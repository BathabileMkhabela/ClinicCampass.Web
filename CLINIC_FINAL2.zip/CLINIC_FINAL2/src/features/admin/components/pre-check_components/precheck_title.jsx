import '../../../../styles/admin_styles.css'
export default function PrecheckTitle({title}){
    return(
        <div className="precheck_title_container">
            <p>{title}</p>
        </div>
    );
}