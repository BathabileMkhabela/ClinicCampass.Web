export default function SavePrecheckInfoBtn(){
    return(
        <div className="savePreCheckInfoBtn_container">
            <button type="button">Save</button>
        </div>
    );
}