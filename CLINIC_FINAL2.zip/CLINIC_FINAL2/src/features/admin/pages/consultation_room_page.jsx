/*import TopHomeHeader from "../../components/header";*/
import ConsultationRoomBody from "../components/consultation_room_components/consultation_room_body";
export default function ConsultationRoomPage(){
    return(
    <>
       
        <ConsultationRoomBody/>
    </>
    );
}